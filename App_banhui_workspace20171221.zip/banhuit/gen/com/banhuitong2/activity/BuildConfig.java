/** Automatically generated file. DO NOT MODIFY */
package com.banhuitong2.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}