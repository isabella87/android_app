package com.banhuitong2.inf;

public interface MyDialogInterface {

	public void onButtonSure();
	public void onButtonCancel();
}
