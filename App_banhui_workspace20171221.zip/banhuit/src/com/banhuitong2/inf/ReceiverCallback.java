package com.banhuitong2.inf;

public interface ReceiverCallback {
	
	public void callback(String action);
	
}
