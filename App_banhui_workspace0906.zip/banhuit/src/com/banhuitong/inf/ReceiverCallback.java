package com.banhuitong.inf;

public interface ReceiverCallback {
	
	public void callback(String action);
	
}
