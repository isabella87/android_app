package com.banhuitong.inf;

public interface MyDialogInterface {

	public void onButtonSure();
	public void onButtonCancel();
}
