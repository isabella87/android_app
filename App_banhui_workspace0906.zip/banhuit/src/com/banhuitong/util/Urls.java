package com.banhuitong.util;


public class Urls {
	
	public static final String URL_4 = Constants.accsrvUrl + "account/sign-in";
//	public static final String URL_5 = Constants.accsrvUrl + "account/sign-out";
//	public static final String URL_14 = Constants.p2psrvUrl + "app/apk-info";
//	public static final String URL_15 = Constants.p2psrvUrl + "reg/rcode-url";
//	public static final String URL_17 = Constants.p2psrvUrl + "reg/mobile";
//	public static final String URL_30 = Constants.p2psrvUrl + "app/update-app-user";
}
